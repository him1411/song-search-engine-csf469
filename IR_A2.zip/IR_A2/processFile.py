import os
import time
import shutil
import sys
import numpy
import math
import random
import igraph
import imageio
from scipy import sparse
from igraph import *


#store text file in a list
global rawTextData, rawTextDataCopy
rawTextData = []
rawTextDataCopy = []

#Stores a list of nodes in numeric form
global nodeList
nodeList = []

#List of nodes that were deleted from the web graph.
global deletedNodesList
deletedNodesList = []

#Stores list of nodes in URL form, the index of the node in this list
#is the corresponding node number.
global linkToNum
linkToNum = []

#processed_Data_Dictionary
#  Key : Node number
#  Value : List of toNodes
global processed_Data_Dictionary #,processed_Data_Dictionary_Copy
processed_Data_Dictionary = {}
processed_Data_Dictionary_Copy = {}

global rankedLinksList
rankedLinksList = []

plotNum = 1
layoutFlag = 1
layout = []
x=1
rankMatrix = []

'''
Check whether sum of column values of difference matrix, formed by subtracting
old rank matrix and new new rank matrix, is less than some threshold value.
'''
def checkConvergence(rankMatrix_old, rankMatrix_new):
    subMatrix = rankMatrix_old - rankMatrix_new
    sum = 0
    for rankDif in subMatrix:
        sum = sum + abs(rankDif[0])
    if sum<0.001:
        return False
    else:
        return True

'''
Read the nodes and their corresponding links from the data file.
Assign every node(URL) a unique integer (index of the linkToNum list).
Write the links (FromNode : ToNode in numeric format) to a separate file 'processedLinksData'
'''
def createNodeToNum(stringData):

    with open(stringData) as fread:
        lineList = []       #store the read line, in this list.
        for line in fread:
            lineList = line.split(' ')
            lineList[1] = lineList[1].strip('\n')       #lineList[1] -> from node, lineList[2] -> to node
            if lineList[0] not in linkToNum:
                linkToNum.append(lineList[0])
            if lineList[1] not in linkToNum:
                linkToNum.append(lineList[1])

            #write the new link in numeric format to processedLinksData
            with open('processedLinksData','a') as fwrite:
                fwrite.write(str(linkToNum.index(lineList[0])) + ' ' + str(linkToNum.index(lineList[1])) + '\n')


#read the file line by line, and create rawTextdata 2D list
'''
Read processedLinksData line by line,
append every link in [fromNode,ToNode] format to rawTextData list.
Thus, rawTextData is a list of links.
'''
def createRawTextData():
    with open('processedLinksData') as f:
        lineList = []
        for line in f:
            lineList = line.split(' ')
            lineList[1] = lineList[1].strip('\n')
            rawTextData.append(lineList);
    global rawTextDataCopy
    rawTextDataCopy = rawTextData


#create processeddataDictionary, key: link, value: list of tolinks
'''
Create a dictionary (processed_Data_Dictionary), with key as node (Number), and value as
list of all toNodes, {node:[list_of_to_nodes]}
Also, create a list (nodeList) containing the nodes in the web graph.
'''
def createProcessed_Data_dictionary():

    tempList = []           #temporary list, for storing a list in rawTextData
    global processed_Data_Dictionary_Copy

    #Create processed_Data_Dictionary
    for tempList in rawTextData:
        if tempList[0] not in processed_Data_Dictionary:
            processed_Data_Dictionary[tempList[0]] = [tempList[1]]
        else:
            processed_Data_Dictionary[tempList[0]].append(tempList[1])

        #Update nodeList
        if tempList[0] not in nodeList:
            nodeList.append(tempList[0])
        if tempList[1] not in nodeList:
            nodeList.append(tempList[1])
    processed_Data_Dictionary_Copy = processed_Data_Dictionary


#process those nodes who have no toLinks
'''
Some nodes do not have any to nodes, they nevertheless need
to be added to processed_Data_Dictionary with key as the node and value as an empty list.
'''
def handleLinks_with_No_ToNodes():
    for node in nodeList:
        if node not in processed_Data_Dictionary:
            processed_Data_Dictionary[node] = []


#create the link matrix
'''
Create the link matrix, an nXn matrix where n is the number of nodes.
'''
def createLinkMatrix(matrixM):
    for node in processed_Data_Dictionary:
        numOfToLinks = len(processed_Data_Dictionary[node])
        for toLink in processed_Data_Dictionary[node]:
            matrixM[int(toLink)][int(node)] = 1/numOfToLinks
    return matrixM

'''
Find the rank matrix using power iteration method.
    Page rank Equation  : newRankMatrix = (matrixM*oldRankMatrix) + teleportMatrix
Stop when newRankMatrix is nearly equal to old rank matrix, according to a certain
threshold value (0.001) as defined in checkConvergence method.
'''
def performPowerIteration(matrixM,oldRankMatrix,newRankMatrix,teleportMatrix):
    while checkConvergence(numpy.asarray(newRankMatrix.todense()),numpy.asarray(oldRankMatrix.todense())):
        oldRankMatrix = newRankMatrix
        newRankMatrix = (matrixM*oldRankMatrix) + teleportMatrix
        visualisePageRank(numpy.asarray(newRankMatrix.todense()))
        print(newRankMatrix)
    return numpy.asarray(newRankMatrix.todense())

'''
Create a png image for page rank visualisation.
'''
def visualisePageRank(newRankMatrix):

    g = Graph(directed=True)        #Directed graph igraph declaration
    global plotNum,deletedNodesList
    nodeList.sort()

    #create a color pallet to color deferent nodes according to their page rank.
    num_colors = 100
    palette = RainbowPalette(n=num_colors)
    color_list = []
    for i in range(num_colors):
        color_list.append(palette.get(i))

    #Add node to plot, set node size according to page rank.
    for node in nodeList:
        if len(deletedNodesList)==0:
            size = 10*60*newRankMatrix[int(node)][0]
            g.add_vertex(name = node,color = color_list[int(size%98)],label = node, size = 10*60*newRankMatrix[int(node)][0])
        elif node not in deletedNodesList:
            size = 10*60*newRankMatrix[int(node)][0]
            g.add_vertex(name = node,color = color_list[int(size%98)],label = node, size = 10*60*newRankMatrix[int(node)][0])

    global layoutFlag           #layout flag = 0 if we want to maintain the same coordinate positions of the nodes in the visualisation.
    global layout               #layout is a 2D list, containing the x and y coordinates of every node.
    if layoutFlag==1:
        layout = g.layout_lgl()   #large graph layout for graphs with large number of links and nodes.
        for l in layout:
            print(l)
            l[0] = l[0]/2
            l[1] = l[1]/2
        layout[0][0] = 0
        layout[0][1] = 0
        layoutFlag = 0

    #add edges to plot
    global x
    for edge in rawTextData:
        #Do not add an edge which contains a deleted node.
        if len(deletedNodesList)==0 or edge[0] not in deletedNodesList and edge[1] not in deletedNodesList  :
            print(edge[0] + " " + edge[1])
            g.add_edge(edge[0],edge[1])
            #plot(g,'Images/g'+str(x)+'.png',layout = layout,bbox =(656,364))
            #x = x + 1

    plot(g,'Final_images/g'+str(plotNum)+'.png',layout = layout,bbox =(656,364))
    plotNum = plotNum + 1       #plotNum indicates the number of plots created, and is also used to name the .png images.


'''
Create rankedLinksList, which contains nodes in
increasing order of their page rank.
'''
def rankVertices(newRankMatrix):
    for linkVal in newRankMatrix:
        i=0
        maxVal=0        #max page rank value among the nodes yet to be added to rankedLinksList
        maxLinkNum=0    #node number having max page rank value, among the nodes yet to be added to rankedLinksList
        for linkVal in newRankMatrix:
            if linkVal[0]>maxVal and linkToNum[i] not in rankedLinksList:
                maxVal = linkVal[0]
                maxLinkNum = i
            i+=1
        rankedLinksList.append(linkToNum[maxLinkNum])

'''
Stich .png images of every iteration in power iteration, into an animated gif.
'''
def createGif(imageFolder,gifName):

    image_files = os.listdir(imageFolder)
    for i in range(0,len(image_files)):
        image_files[i] = os.path.join(imageFolder,image_files[i])
    image_files.sort()
    images = []
    for filename in image_files:
        images.append(imageio.imread(filename))
    imageio.mimsave(gifName, images,duration=0.7)

'''
The function to be called to run page rank
    1.Choosing a graph data .txt file.
    2.Creating and initialising different matrices in page rank equation, using sparse matrix representation
    3.Applying the power iteration method to calculate the rank matrix.
    4.Visualising page rank using igraph library.
'''
def main(stringDataFile, newEdgeFlag, imageFolder1, imageFolder2):
    global plotNum,layoutFlag,rankMatrix,processed_Data_Dictionary,rawTextData,rankedLinksList,nodeList,linkToNum

    #Set the directory for saving the png images for Visualising page rank.
    filelist = [ f for f in os.listdir('/home/subhadip/PageRankTester/Images/')]
    for f in filelist:
        os.remove(os.path.join('/home/subhadip/PageRankTester/Images/', f))

    filelist = [ f for f in os.listdir('/home/subhadip/PageRankTester/Final_images/')]
    for f in filelist:
        os.remove(os.path.join('/home/subhadip/PageRankTester/Final_images/', f))

    plotNum = 1

    #Primary purpose of this block is to create processed_Data_Dictionary which contains
    #node number as key and corresponding list of toNodes as value.
    #This if block runs only once for a choosen web graph. However, if the web graph is modified
    #by adding edges or deleting nodes, this block doesn't run.
    if newEdgeFlag == 0:
        open('processedLinksData','w').close()
        processed_Data_Dictionary = {}
        rawTextData = []
        linkToNum = []
        rawTextData = []
        nodeList = []

        createNodeToNum(stringDataFile)
        createRawTextData()
        createProcessed_Data_dictionary()
        handleLinks_with_No_ToNodes()
        print(nodeList)
        print(processed_Data_Dictionary)

    rankedLinksList = []
    ini_rank = 1/int(len(nodeList))
    #create link matrix M.
    matrixM = numpy.zeros((int(len(nodeList)),int(len(nodeList))))
    matrixM = createLinkMatrix(matrixM)
    matrixM = 0.80*matrixM
    matrixM = sparse.csr_matrix(matrixM)

    #create rank vector
    oldRankMatrix = numpy.zeros((int(len(nodeList)),1))
    for r in oldRankMatrix:
        r[0] = ini_rank
    oldRankMatrix = sparse.csr_matrix(oldRankMatrix)

    #create teleport matrix
    teleportMatrix = numpy.zeros((int(len(nodeList)),1))
    for t in teleportMatrix:
        t[0] = 0.20*ini_rank
    teleportMatrix = sparse.csr_matrix(teleportMatrix)

    #Initialise newRankMatrix by applying page rank equation once.
    newRankMatrix = (matrixM*oldRankMatrix) + teleportMatrix
    visualisePageRank(numpy.asarray(newRankMatrix.todense()))

    #Perform Power Iteration to calculate final rank matrix
    newRankMatrix = performPowerIteration(matrixM,oldRankMatrix,newRankMatrix,teleportMatrix)
    rankMatrix = newRankMatrix
    visualisePageRank(newRankMatrix)

    rankVertices(newRankMatrix)
    #createGif(imageFolder1,'movie1.gif')
    createGif(imageFolder2,'movie2.gif')


#clear processedLinksData .txt file
open('processedLinksData','w').close()
#main('stringData.txt',0,'/home/subhadip/PageRankTester/Images/','/home/subhadip/PageRankTester/Final_images/')
